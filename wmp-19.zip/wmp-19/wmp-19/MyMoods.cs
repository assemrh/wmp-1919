﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wmp_19
{
    internal class StyleSec // Class
    {

        static AsraMP myClass = Application.OpenForms.OfType<AsraMP>().FirstOrDefault();
        static OptionsForm myClassmd = Application.OpenForms.OfType<OptionsForm>().FirstOrDefault();
        //static AboutBox1 myClassmd3 = Application.OpenForms.OfType<AboutBox1>().FirstOrDefault();


        public static void Darkmod19 () //Method
        {
            //AsraMP asramp1 = new AsraMP(); // AsraMP is Form's name
            myClass.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.aboutASRAMPToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.aboutToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.exitToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.fileToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.label1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.label2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClass.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.listBoxSongs.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClass.MyWMP.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.Openbtn1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.openToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.optionsToolStripMenuItem.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.Pausebtn1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.Playbtn1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.progressBar1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClass.radioButton1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClass.radioButton2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.Stopbtn1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.ta7it.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClass.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClassmd.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClassmd.tableLayoutPanel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClassmd.radiobtnDark.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClassmd.radiobtnLight.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            myClassmd.radiobtnMavi.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClassmd3.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClassmd3.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClassmd3.label1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClassmd3.label4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            //myClassmd3.BackColor = System.Drawing.SystemColors.ControlDarkDark;

        }

        public static void Lightmod19() //Method
        {
            //AsraMP asramp1 = new AsraMP(); // AsraMP is Form's name
            myClass.BackColor = System.Drawing.SystemColors.Control;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.Control;
            myClass.aboutASRAMPToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.aboutToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.Control;
            myClass.exitToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.fileToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.label1.BackColor = System.Drawing.SystemColors.Control;
            myClass.label2.BackColor = System.Drawing.SystemColors.Control;
            //myClass.label3.BackColor = System.Drawing.SystemColors.Control;
            myClass.listBoxSongs.BackColor = System.Drawing.SystemColors.Control;
            //myClass.MyWMP.BackColor = System.Drawing.SystemColors.Control;
            myClass.Openbtn1.BackColor = System.Drawing.SystemColors.Control;
            myClass.openToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.optionsToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            myClass.panel1.BackColor = System.Drawing.SystemColors.Control;
            myClass.panel2.BackColor = System.Drawing.SystemColors.Control;
            myClass.Pausebtn1.BackColor = System.Drawing.SystemColors.Control;
            myClass.Playbtn1.BackColor = System.Drawing.SystemColors.Control;
            myClass.progressBar1.BackColor = System.Drawing.SystemColors.Control;
            //myClass.radioButton1.BackColor = System.Drawing.SystemColors.Control;
            //myClass.radioButton2.BackColor = System.Drawing.SystemColors.Control;
            myClass.BackColor = System.Drawing.SystemColors.Control;
            myClass.Stopbtn1.BackColor = System.Drawing.SystemColors.Control;
            myClass.ta7it.BackColor = System.Drawing.SystemColors.Control;
            myClass.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Control;
            myClass.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.tableLayoutPanel.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.radiobtnDark.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.radiobtnLight.BackColor = System.Drawing.SystemColors.Control;
            myClassmd.radiobtnMavi.BackColor = System.Drawing.SystemColors.Control;
            //    myClassmd3.label3.BackColor = System.Drawing.SystemColors.Control;
            //    myClassmd3.panel2.BackColor = System.Drawing.SystemColors.Control;
            //    myClassmd3.label1.BackColor = System.Drawing.SystemColors.Control;
            //    myClassmd3.label4.BackColor = System.Drawing.SystemColors.Control;
            //    myClassmd3.BackColor = System.Drawing.SystemColors.Control;
        } 

        public static void Mavimod19() //Method
        {
            //AsraMP asramp1 = new AsraMP(); // AsraMP is Form's name
            myClass.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.aboutASRAMPToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.aboutToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.anamenu.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.exitToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.fileToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.label2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClass.label3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.listBoxSongs.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClass.MyWMP.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.Openbtn1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.openToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.optionsToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.Pausebtn1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.Playbtn1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.progressBar1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClass.radioButton1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClass.radioButton2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.Stopbtn1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.ta7it.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClass.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClassmd.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClassmd.tableLayoutPanel.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClassmd.radiobtnDark.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClassmd.radiobtnLight.BackColor = System.Drawing.SystemColors.MenuHighlight;
            myClassmd.radiobtnMavi.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClassmd3.label3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClassmd3.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClassmd3.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClassmd3.label4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            //myClassmd3.BackColor = System.Drawing.SystemColors.MenuHighlight;
        }

    }
}