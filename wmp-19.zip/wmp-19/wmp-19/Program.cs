﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wmp_19
{
    internal class Baslat // Başlatma Class
    {
        static AsraMP myClass = Application.OpenForms.OfType<AsraMP>().FirstOrDefault(); // ANAFORM 

        public static void Sec() //Method
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Multiselect = true; 
                ofd.Filter = "All Supported Audio |*.mp3; *.wma; *.m4a; |MP3s|*.mp3; |WMAs|*.wma;|All files (*.*)|*.*";
                if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    myClass.dosya = ofd.SafeFileNames;
                    myClass.yol = ofd.FileNames;

                    for (int i = 0; i < myClass.dosya.Length; i++)
                    {
                        myClass.listBoxSongs.Items.Add(myClass.dosya[i]);
                    }
                }

            }
            catch
            {
                MessageBox.Show("Hata");
            }
        }

    }
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() // ana class
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AsraMP());
 
        }
    }
}
