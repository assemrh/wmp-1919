﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wmp_19
{
    public partial class AsraMP : Form
    {
        public AsraMP()
        {
            InitializeComponent();
        }

       public string[] dosya, yol;
        private void AsraMP_Load(object sender, EventArgs e)
        {
            progressBar1.Value = 0;

        }
        private void Playbtn1_Click(object sender, EventArgs e)
        {
            MyWMP.Ctlcontrols.play();
        }
        private void Pausebtn1_Click(object sender, EventArgs e)
        {
            MyWMP.Ctlcontrols.pause();
        }
        private void Stopbtn1_Click(object sender, EventArgs e)
        {
            MyWMP.Ctlcontrols.stop();
        }
        private void Openbtn1_Click(object sender, EventArgs e)
        {
            Baslat.Sec();           
        }


        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            timer1.Start();
            MyWMP.URL = openFileDialog1.FileName;
            openFileDialog1.Filter = "All Supported Audio | *.mp3; *.wma; *.m4a; | MP3s | *.mp3 | WMAs | *.wma |All files (*.*)|*.*";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MyWMP.URL = yol[listBoxSongs.SelectedIndex];
                timer1.Start();


            }
            catch
            {
                MessageBox.Show("Hata");
            }

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
             int len = Convert.ToInt32(MyWMP.currentMedia.duration);
             int cur = Convert.ToInt32(MyWMP.Ctlcontrols.currentPosition);
            //progressBar1.Value = cur;
            progressBar1.Maximum = len;
            progressBar1.Value = cur;
            if (progressBar1.Value == len)
            {
                progressBar1.Value = 0;
            }
           
            int kalan = len - cur;
            label4.Text = Convert.ToString(cur/60) + ":" + Convert.ToString(cur%60);
            label3.Text = Convert.ToString(kalan / 60) + ":" + Convert.ToString(kalan % 60);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void aboutASRAMPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 f2 = new AboutBox1();
            f2.ShowDialog(); // About Formu gösterme
        }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Baslat.Sec();          
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Options op2 = new Options();
            op2.ShowDialog();
        }   

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
           
        }



        private void secbtn_Click(object sender, EventArgs e)
        {
            Baslat.Sec();           
        }
    }
}